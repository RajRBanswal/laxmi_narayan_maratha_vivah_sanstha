<?php
require("./navbar.php");
?>


<?php
require("./footer.php");
?>